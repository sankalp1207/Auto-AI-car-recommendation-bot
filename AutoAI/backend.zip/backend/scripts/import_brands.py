import pandas as pd
from pathlib import Path

from backend.app.database.database import SessionLocal
from backend.app.models.brand import Brand

db = SessionLocal()

BASE_DIR = Path(__file__).resolve().parents[2]
CSV = BASE_DIR / "backend" / "data" / "brands.csv"

df = pd.read_csv(CSV)

for _, row in df.iterrows():

    exists = db.query(Brand).filter(
        Brand.name == row["name"]
    ).first()

    if exists:
        continue

    db.add(
        Brand(
            name=row["name"],
            country=row["country"],
        )
    )

db.commit()
db.close()

print("Brands imported successfully.")