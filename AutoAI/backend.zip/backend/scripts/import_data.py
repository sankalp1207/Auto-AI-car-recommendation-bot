import pandas as pd
from pathlib import Path

from backend.app.database.database import SessionLocal, Base, engine
from backend.app.models.car import Car

# -------------------------------------------------------
# Create tables if they don't exist
# -------------------------------------------------------
Base.metadata.create_all(bind=engine)

# -------------------------------------------------------
# Database session
# -------------------------------------------------------
db = SessionLocal()

# -------------------------------------------------------
# CSV path
# -------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parents[2]
CSV_FILE = BASE_DIR / "data" / "cars.csv"

print(f"Reading CSV from: {CSV_FILE}")

# -------------------------------------------------------
# Read CSV
# -------------------------------------------------------
df = pd.read_csv(CSV_FILE)

# -------------------------------------------------------
# Remove existing data (optional)
# -------------------------------------------------------
db.query(Car).delete()
db.commit()

# -------------------------------------------------------
# Insert cars
# -------------------------------------------------------
for _, row in df.iterrows():

    car = Car(
        brand=row["brand"],
        model=row["model"],
        variant=row["variant"],

        ex_showroom_price=float(row["ex_showroom_price"]),

        body_type=row["body_type"],
        fuel_type=row["fuel_type"],
        transmission=row["transmission"],

        engine_cc=int(row["engine_cc"]),
        power=int(row["power"]),
        torque=int(row["torque"]),

        mileage=float(row["mileage"]),

        seating=int(row["seating"]),

        boot_space=int(row["boot_space"]),

        ground_clearance=int(row["ground_clearance"]),

        safety_rating=float(row["safety_rating"]),

        maintenance_cost=int(row["maintenance_cost"]),

        resale_rating=float(row["resale_rating"]),

        city_use=bool(row["city_use"]),
        highway_use=bool(row["highway_use"]),
        family_friendly=bool(row["family_friendly"]),

        pros=row["pros"],
        cons=row["cons"],
        image_url=row.get("image_url"),
    )

    db.add(car)

# -------------------------------------------------------
# Commit
# -------------------------------------------------------
db.commit()
db.close()

print("Cars imported successfully!")