import pandas as pd

from app.database.database import SessionLocal
from app.models.car import Car

db = SessionLocal()

df = pd.read_excel("data/AutoAI_1000_Cars_Dataset.xlsx")

for _, row in df.iterrows():

    car = Car(
        brand=row["brand"],
        model=row["model"],
        variant=row["variant"],
        year=int(row["year"]),
        price=float(row["price_inr"]),
        fuel_type=row["fuel_type"],
        transmission=row["transmission"],
        body_type=row["body_type"],
        seats=int(row["seats"]),
        mileage=float(row["mileage_or_range"]),
        engine_cc=int(row["engine_cc"]),
        horsepower=int(row["horsepower"]),
        drivetrain=row["drivetrain"],
        safety_rating=int(row["safety_rating"]),
        image_url=row["image_url"],
    )

    db.add(car)

db.commit()
db.close()

print("Successfully imported cars.")