from backend.app.database.database import Base, engine
from backend.app.models.car import Car

print("Creating tables...")
Base.metadata.create_all(bind=engine)
print("Done!")

print(Base.metadata.tables.keys())