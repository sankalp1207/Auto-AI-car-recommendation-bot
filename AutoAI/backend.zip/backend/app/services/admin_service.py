from sqlalchemy.orm import Session
from backend.app.models.car import Car


def get_all_cars(db: Session):
    return db.query(Car).all()


def add_car(db: Session, car_data):
    car = Car(**car_data.dict())
    db.add(car)
    db.commit()
    db.refresh(car)
    return car


def update_car(db: Session, car_id: int, car_data):
    car = db.query(Car).filter(Car.id == car_id).first()

    if not car:
        return None

    for key, value in car_data.dict().items():
        setattr(car, key, value)

    db.commit()
    db.refresh(car)

    return car


def delete_car(db: Session, car_id: int):
    car = db.query(Car).filter(Car.id == car_id).first()

    if not car:
        return False

    db.delete(car)
    db.commit()

    return True