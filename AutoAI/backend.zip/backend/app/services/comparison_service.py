from sqlalchemy.orm import Session
from backend.app.models.car import Car


def compare_cars(request, db: Session):

    car1 = db.query(Car).filter(Car.id == request.car1_id).first()
    car2 = db.query(Car).filter(Car.id == request.car2_id).first()

    if not car1 or not car2:
        return {
            "error": "One or both cars not found."
        }

    return {
        "car1": {
            "id": car1.id,
            "brand": car1.brand,
            "model": car1.model,
            "variant": car1.variant,
            "price": car1.ex_showroom_price,
            "fuel": car1.fuel_type,
            "transmission": car1.transmission,
            "engine_cc": car1.engine_cc,
            "power": car1.power,
            "torque": car1.torque,
            "mileage": car1.mileage,
            "seating": car1.seating,
            "boot_space": car1.boot_space,
            "ground_clearance": car1.ground_clearance,
            "safety_rating": car1.safety_rating,
        },
        "car2": {
            "id": car2.id,
            "brand": car2.brand,
            "model": car2.model,
            "variant": car2.variant,
            "price": car2.ex_showroom_price,
            "fuel": car2.fuel_type,
            "transmission": car2.transmission,
            "engine_cc": car2.engine_cc,
            "power": car2.power,
            "torque": car2.torque,
            "mileage": car2.mileage,
            "seating": car2.seating,
            "boot_space": car2.boot_space,
            "ground_clearance": car2.ground_clearance,
            "safety_rating": car2.safety_rating,
        }
    }