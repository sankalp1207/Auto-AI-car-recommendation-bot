from sqlalchemy.orm import Session
from backend.app.models.car import Car


def recommend_cars(request, db: Session):

    cars = db.query(Car).all()

    recommendations = []

    for car in cars:

        score = 0
        reasons = []

        # Budget (30)
        if car.ex_showroom_price <= request.budget:
            score += 30
            reasons.append("Within Budget")

        # Fuel (20)
        if (
            request.fuel_type
            and car.fuel_type
            and car.fuel_type.lower() == request.fuel_type.lower()
        ):
            score += 20
            reasons.append("Preferred Fuel")

        # Transmission (15)
        if (
            request.transmission
            and car.transmission
            and car.transmission.lower() == request.transmission.lower()
        ):
            score += 15
            reasons.append("Preferred Transmission")

        # Body Type (15)
        if (
            hasattr(request, "body_type")
            and request.body_type
            and car.body_type
            and car.body_type.lower() == request.body_type.lower()
        ):
            score += 15
            reasons.append("Preferred Body Type")

        # Family Size (10)
        if car.seating >= request.family_members:
            score += 10
            reasons.append("Enough Seats")

        # City Driving (5)
        if hasattr(request, "city_drive"):
            if request.city_drive and car.city_use:
                score += 5
                reasons.append("Good for City")

        # Highway Driving (5)
        if hasattr(request, "highway_drive"):
            if request.highway_drive and car.highway_use:
                score += 5
                reasons.append("Good for Highway")

        # Priority
        priority = request.priority.lower()

        if priority == "safety":
            score += car.safety_rating * 5
            reasons.append("Excellent Safety")

        elif priority == "mileage":
            score += car.mileage
            reasons.append("Good Mileage")

        elif priority == "maintenance":
            score += max(0, 20 - (car.maintenance_cost / 5000))
            reasons.append("Low Maintenance")

        elif priority == "resale":
            score += car.resale_rating * 5
            reasons.append("High Resale Value")

        recommendations.append(
            {
                "id": car.id,
                "brand": car.brand,
                "model": car.model,
                "variant": car.variant,
                "price": car.ex_showroom_price,
                "image": car.image_url,
                "fuel_type": car.fuel_type,
                "transmission": car.transmission,
                "seating_capacity": car.seating,   # ✅ Fixed
                "score": round(score, 2),
                "reasons": reasons,
            }
        )

    recommendations.sort(
        key=lambda x: x["score"],
        reverse=True,
    )

    return recommendations[:5]