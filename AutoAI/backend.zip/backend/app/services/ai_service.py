import re
from openai import OpenAI

client = OpenAI(
    base_url="http://127.0.0.1:1234/v1",
    api_key="lm-studio"
)


def extract_preferences(message: str):

    message = message.lower()

    budget = 2000000

    budget_match = re.search(r'(\d+)\s*lakh', message)

    if budget_match:
        budget = int(budget_match.group(1)) * 100000

    fuel = "Petrol"

    if "diesel" in message:
        fuel = "Diesel"

    elif "cng" in message:
        fuel = "CNG"

    elif "electric" in message or "ev" in message:
        fuel = "EV"

    transmission = "Manual"

    if "automatic" in message:
        transmission = "Automatic"

    family = 5

    family_match = re.search(r'(\d+)\s*(members|people|persons)', message)

    if family_match:
        family = int(family_match.group(1))

    priority = "Safety"

    if "mileage" in message:
        priority = "Mileage"

    elif "maintenance" in message:
        priority = "Maintenance"

    elif "performance" in message:
        priority = "Performance"

    body_type = None

    if "suv" in message:
        body_type = "SUV"

    elif "sedan" in message:
        body_type = "Sedan"

    elif "hatchback" in message:
        body_type = "Hatchback"

    return {
        "budget": budget,
        "fuel_type": fuel,
        "transmission": transmission,
        "family_members": family,
        "priority": priority,
        "body_type": body_type,
        "city_drive": True,
        "highway_drive": True,
        "maintenance_sensitive": False
    }


def explain_recommendations(message, recommendations):

    prompt = f"""
User Request:

{message}

Recommended Cars:

{recommendations}

Explain why these cars are suitable.

Keep it under 150 words.
"""

    response = client.chat.completions.create(
        model="google/gemma-4-4b",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.3
    )

    return response.choices[0].message.content