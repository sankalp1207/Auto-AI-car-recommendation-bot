from pydantic import BaseModel


class RecommendationRequest(BaseModel):
    budget: int

    fuel_type: str

    transmission: str

    family_members: int

    priority: str

    body_type: str | None = None

    city_drive: bool = True

    highway_drive: bool = False

    maintenance_sensitive: bool = False