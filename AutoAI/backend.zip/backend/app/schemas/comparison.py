from pydantic import BaseModel

class ComparisonRequest(BaseModel):
    car1_id: int
    car2_id: int