from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.app.database.database import engine, Base

from backend.app.models.car import Car
from backend.app.routers.recommendation_router import router as recommendation_router
from backend.app.routers.chat_router import router as chat_router
from backend.app.routers.comparison_router import router as comparison_router

from backend.app.models.wishlist import Wishlist
from backend.app.routers.wishlist_router import router as wishlist_router

from backend.app.models.user import User
from backend.app.routers.auth_router import router as auth_router
from backend.app.routers.car_router import router as car_router
from backend.app.routers.dashboard_router import router as dashboard_router
from backend.app.routers.search_router import router as search_router
from backend.app.routers.admin_router import router as admin_router

# Create all tables
print("DATABASE:", engine.url)
print("Creating tables...")
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AutoAI",
    version="1.0.0"
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(recommendation_router)
app.include_router(chat_router)
app.include_router(comparison_router)
app.include_router(wishlist_router)
app.include_router(auth_router)
app.include_router(car_router)
app.include_router(dashboard_router)
app.include_router(search_router)
app.include_router(admin_router)
@app.get("/")
def home():
    return {
        "status": "running",
        "project": "AutoAI"
    }