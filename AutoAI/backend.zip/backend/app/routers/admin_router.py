from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.app.database.database import get_db
from backend.app.schemas.admin_schema import CarCreate, CarUpdate
from backend.app.services.admin_service import (
    get_all_cars,
    add_car,
    update_car,
    delete_car,
)

router = APIRouter(
    prefix="/admin",
    tags=["Admin"],
)


@router.get("/cars")
def all_cars(db: Session = Depends(get_db)):
    return get_all_cars(db)


@router.post("/cars")
def create_car(
    car: CarCreate,
    db: Session = Depends(get_db),
):
    return add_car(db, car)


@router.put("/cars/{car_id}")
def edit_car(
    car_id: int,
    car: CarUpdate,
    db: Session = Depends(get_db),
):
    updated = update_car(db, car_id, car)

    if not updated:
        raise HTTPException(404, "Car not found")

    return updated


@router.delete("/cars/{car_id}")
def remove_car(
    car_id: int,
    db: Session = Depends(get_db),
):
    deleted = delete_car(db, car_id)

    if not deleted:
        raise HTTPException(404, "Car not found")

    return {"message": "Car deleted successfully"}
    