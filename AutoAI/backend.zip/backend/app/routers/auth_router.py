from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.database.database import get_db

from backend.app.schemas.auth import (
    UserRegister,
    UserLogin,
)

from backend.app.services.auth_service import (
    register_user,
    login_user,
)

router = APIRouter(
    prefix="/auth",
    tags=["Authentication"]
)


@router.post("/register")
def register(
    request: UserRegister,
    db: Session = Depends(get_db),
):
    return register_user(request, db)


@router.post("/login")
def login(
    request: UserLogin,
    db: Session = Depends(get_db),
):
    return login_user(request, db)