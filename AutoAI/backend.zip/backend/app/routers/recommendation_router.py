from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.database.database import get_db
from backend.app.schemas.recommendation import RecommendationRequest
from backend.app.services.recommendation_service import recommend_cars

router = APIRouter(
    prefix="/recommend",
    tags=["Recommendation"]
)

@router.post("/")
def recommend(
    request: RecommendationRequest,
    db: Session = Depends(get_db),
):
    return recommend_cars(request, db)