from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.database.database import get_db
from backend.app.models.car import Car

router = APIRouter(
    prefix="/cars",
    tags=["Cars"]
)


@router.get("/")
def get_all_cars(db: Session = Depends(get_db)):
    return db.query(Car).all()


@router.get("/{car_id}")
def get_car(car_id: int, db: Session = Depends(get_db)):
    car = (
        db.query(Car)
        .filter(Car.id == car_id)
        .first()
    )

    if not car:
        return {
            "message": "Car not found"
        }

    return car