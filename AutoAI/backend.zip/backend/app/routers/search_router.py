from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.database.database import get_db
from backend.app.services.search_service import search_cars

router = APIRouter(
    prefix="/search",
    tags=["Search"],
)


@router.get("/")
def search(
    brand: str = None,
    fuel: str = None,
    transmission: str = None,
    body_type: str = None,
    budget: float = None,
    db: Session = Depends(get_db),
):

    cars = search_cars(
        db,
        brand,
        fuel,
        transmission,
        body_type,
        budget,
    )

    return cars