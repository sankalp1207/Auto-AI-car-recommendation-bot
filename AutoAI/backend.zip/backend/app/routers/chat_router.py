from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.database.database import get_db
from backend.app.schemas.chat import ChatRequest

from backend.app.services.ai_service import (
    extract_preferences,
    explain_recommendations,
)

from backend.app.services.recommendation_service import recommend_cars


router = APIRouter(
    prefix="/chat",
    tags=["AI Chat"]
)


@router.post("/")
def chat(
    request: ChatRequest,
    db: Session = Depends(get_db),
):

    # Extract user preferences using AI
    preferences = extract_preferences(request.message)

    # Create recommendation object
    class RecommendationRequest:
        pass

    recommendation_request = RecommendationRequest()

    recommendation_request.budget = preferences["budget"]
    recommendation_request.fuel_type = preferences["fuel_type"]
    recommendation_request.transmission = preferences["transmission"]
    recommendation_request.family_members = preferences["family_members"]
    recommendation_request.priority = preferences["priority"]

    # Get recommendations
    recommendations = recommend_cars(
        recommendation_request,
        db
    )

    # Generate AI explanation
    reply = explain_recommendations(
        request.message,
        recommendations
    )

    return {
        "recommendations": recommendations,
        "ai_response": reply
    }