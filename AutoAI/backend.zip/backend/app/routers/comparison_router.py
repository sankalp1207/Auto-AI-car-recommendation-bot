from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.database.database import get_db
from backend.app.models.car import Car
from backend.app.schemas.comparison import ComparisonRequest
from backend.app.services.comparison_service import compare_cars

router = APIRouter(
    prefix="/compare",
    tags=["Comparison"]
)


@router.get("/cars")
def get_all_cars(db: Session = Depends(get_db)):
    cars = db.query(Car).all()

    return [
        {
            "id": car.id,
            "brand": car.brand,
            "model": car.model,
            "variant": car.variant,
        }
        for car in cars
    ]


@router.post("/")
def compare(
    request: ComparisonRequest,
    db: Session = Depends(get_db),
):
    return compare_cars(request, db)